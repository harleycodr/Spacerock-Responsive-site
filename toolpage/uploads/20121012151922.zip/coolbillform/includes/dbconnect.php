<?php

// make db connection
$link = mysql_connect("p41mysql113.secureserver.net", "marian713", "Live2ride!");   
mysql_select_db("marian713") or die("Could not select database");

?>